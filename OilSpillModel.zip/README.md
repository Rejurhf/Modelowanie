Żeby uruchomić użyj komendy:
./OilSpillModel.py

Jeżeli nie działa, poprzedź ją komendą:
chmod +x OilSpillModel.py
